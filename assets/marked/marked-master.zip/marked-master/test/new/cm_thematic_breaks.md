Thematic breaks
===================

### Example 13

***
---
___

### Example 14

+++

### Example 15

===

### Example 16

--
**
__

### Example 17

 ***
  ***
   ***

### Example 18

    ***

### Example 19

Foo
    ***

### Example 20

_____________________________________

### Example 21

 - - -

### Example 22

 **  * ** * ** * **

### Example 23

-     -      -      -

### Example 24

- - - -    

### Example 25

_ _ _ _ a

a------

---a---

### Example 26

 *-*

### Example 27

- foo
***
- bar

### Example 28

Foo
***
bar

### Example 29

Foo
---
bar

### Example 30

* Foo
* * *
* Bar

### Example 31

- Foo
- * * *
