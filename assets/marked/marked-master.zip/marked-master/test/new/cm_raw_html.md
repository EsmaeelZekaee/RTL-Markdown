Raw HTML
===================

### Example 584

<a><bab><c2c>

### Example 585

<a/><b2/>

### Example 586

<a  /><b2
data="foo" >

### Example 587

<a foo="bar" bam = 'baz <em>"</em>'
_boolean zoop:33=zoop:33 />

### Example 588

Foo <responsive-image src="foo.jpg" />

### Example 589

<33> <__>

### Example 590

<a h*#ref="hi">

### Example 591

<a href="hi'> <a href=hi'>

### Example 592

< a><
foo><bar/ >

### Example 593

<a href='bar'title=title>

### Example 594

</a></foo >

### Example 595

</a href="foo">

### Example 596

foo <!-- this is a
comment - with hyphen -->

### Example 599

foo <?php echo $a; ?>

### Example 600

foo <!ELEMENT br EMPTY>

### Example 601

foo <![CDATA[>&<]]>

### Example 602

foo <a href="&ouml;">

### Example 603

foo <a href="\*">
