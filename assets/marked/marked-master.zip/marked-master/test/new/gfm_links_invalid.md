---
sanitize: true
---
This should not be linked: http://example.com/%ff
