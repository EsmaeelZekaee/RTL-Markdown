var marked = require('../../lib/marked.js');

beforeEach(function () {
  marked.setOptions(marked.getDefaults());
});
